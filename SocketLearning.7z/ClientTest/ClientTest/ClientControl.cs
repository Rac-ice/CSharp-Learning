﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClientTest
{
    public class ClientControl
    {
        private Socket clientSocket;
        public ClientControl()
        {
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        public void Connect(string ip, int port)
        {
            clientSocket.Connect(ip, port);//连接
            Console.WriteLine("连接服务器成功");

            Thread threadReceive = new Thread(Receive);
            threadReceive.IsBackground = true;
            threadReceive.Start();
        }

        private void Receive()
        {
            try
            {
                byte[] msg = new byte[1024];
                int msgLength = clientSocket.Receive(msg);
                Console.WriteLine(Encoding.UTF8.GetString(msg, 0, msgLength));
                Receive(); 
            }
            catch 
            {
                Console.WriteLine("服务器断开");
            }
        }

        public void Send()
        {
            Thread threadSend = new Thread(ReadAndSend);
            //threadSend.IsBackground = true;
            threadSend.Start();
        }

        private void ReadAndSend()
        {
            Console.WriteLine("请输入要发送的内容，输入quit退出");
            string msg = Console.ReadLine();
            while (msg != "quit")
            {
                //发送消息
                clientSocket.Send(Encoding.UTF8.GetBytes(msg));
                msg = Console.ReadLine();
            }
        }
    }
}

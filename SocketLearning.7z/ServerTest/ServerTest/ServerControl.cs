﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ServerTest
{
    public class ServerControl
    {
        private Socket serverSocket;
        private List<Socket> clientList;

        public ServerControl()
        {
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            clientList = new List<Socket>();
        }
        //AddressFamily：地址类型
        //SocketType：传输方式
        //ProtocolType：协议
        public void Start()
        {
            serverSocket.Bind(new IPEndPoint(IPAddress.Any, 12321));//绑定ip地址和端口号
            serverSocket.Listen(10);//进行监听
            Console.WriteLine("服务器启动成功");

            //因为Accept方法会阻塞当前线程，所以使用多线程，能够让服务器接收多个客户端连接
            Thread threadAccept = new Thread(Accept);
            threadAccept.IsBackground = true;
            threadAccept.Start();

        }
        
        private void Accept()
        {
            //接收客户端的方法，会挂起当前线程
            Socket client = serverSocket.Accept();
            IPEndPoint point = client.RemoteEndPoint as IPEndPoint;
            Console.WriteLine(point.Address + "[" + point.Port + "]连接成功");
            clientList.Add(client);

            //因为Receive方法会阻塞当前线程，所以使用多线程，能够让服务器接收多条客户端消息
            Thread threadReceive = new Thread(Receive);
            threadReceive.IsBackground = true;
            threadReceive.Start(client);

            //尾递归，能够接收多个客户端连接
            Accept();
        }

        private void Receive(object obj)
        {
            Socket client = obj as Socket;

            IPEndPoint point = client.RemoteEndPoint as IPEndPoint;

            try
            {
                //接收客户端消息
                byte[] msg = new byte[1024];
                int msgLength = client.Receive(msg);
                string msgStr = point.Address + "[" + point.Port + "]：" + Encoding.UTF8.GetString(msg, 0, msgLength);
                Console.WriteLine(msgStr);
                //client.Send(Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(msg, 0, msgLength)+"，接收成功"));

                Broadcast(client, msgStr);

                //尾递归，能够接收多条客户端消息
                Receive(client);
            }
            catch
            {
                Console.WriteLine(point.Address + "[" + point.Port + "]连接断开");
                clientList.Remove(client);
            }
        }

        private void Broadcast(Socket clientOther, string msg)
        {
            foreach (var client in clientList)
            {
                if (client == clientOther)
                {
                    //当前消息是由client发来的，不需要有任何响应
                }
                else
                {
                    client.Send(Encoding.UTF8.GetBytes(msg));
                }
            }
        }
    }
}
